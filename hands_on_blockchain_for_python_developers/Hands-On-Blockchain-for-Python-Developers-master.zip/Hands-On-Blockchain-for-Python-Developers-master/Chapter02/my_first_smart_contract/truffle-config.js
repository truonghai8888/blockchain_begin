module.exports = {
  networks: {
    "development": {
      network_id: 5777,
      host: "localhost",
      port: 7545
    },
  },
  mocha: {
  },
  compilers: {
    solc: {
    }
  }
};
